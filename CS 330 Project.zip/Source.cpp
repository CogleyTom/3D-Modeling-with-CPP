#include <iostream>             // cout, cerr
#include <cstdlib>              // EXIT_FAILURE
#include <GL/glew.h>            // GLEW library
#include <GLFW/glfw3.h>         // GLFW library
#include "Cylinder.h"           // CYLINDER 
#include "Sphere.h"             // Sphere

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "camera.h" // Camera class

// Include the STB image header file to load images
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"     // Image loading Utility functions

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "CS330 Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];         // Handle for the vertex buffer object
        GLuint nIndices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    GLMesh gMeshCube;
    GLMesh gMeshLights;
    GLMesh gMeshLight2;
    GLMesh gMeshPlane;
    GLMesh gMeshCylinder;
    GLMesh gMeshCylinder2;
    GLMesh gMeshSphere;
    GLMesh gMeshCandBase;
    GLMesh gMeshCandCyl;
    GLMesh gMeshTapeOut;
    GLMesh gMeshTapeInner;


    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;


    // Texture id
    GLuint gTextureId;

    // Texture id 2
    GLuint gTextureId2;

    // Texture id 3
    GLuint gTextureId3;

    // Texture id 4
    GLuint gTextureId4;

    // Texture id 5
    GLuint gTextureId5;

    // Texture id 6
    GLuint gTextureId6;

    // Texture id 7
    GLuint gTextureId7;

    // Texture id 8
    GLuint gTextureId8;

    // Texture id 9
    GLuint gTextureId9;

    // Shader program
    GLuint gProgramId;

    // Light shader
    GLuint gLampProgramId;
    GLuint gLamp2ProgramId;
    GLuint gLamp3ProgramId;
    bool ortho = false;


    // camera
    Camera gCamera(glm::vec3(0.0f, 2.0f, 7.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;


    // Set up initial position vector of the cube and model matrix for the cube
    glm::vec3 gCubePos = glm::vec3(-2.0f, 0.0f, 1.0f);
    glm::vec3 gCube2Pos = glm::vec3(0.50f, 1.0f, 0.22f);
    glm::vec3 gPlanePos = glm::vec3(0.0f, 0.0f, 0.0f);
    glm::vec3 gCylinderPos = glm::vec3(0.50f, 0.0f, 0.22f);
    glm::vec3 gCylinder2Pos = glm::vec3(0.50f, 0.20f, 0.22f);
    glm::vec3 gSpherePos = glm::vec3(0.50f, 1.0f, 0.22f);
    glm::vec3 gCandBasePos = glm::vec3(-1.0f, 0.0f, 1.0f);
    glm::vec3 gCandCylPos = glm::vec3(-1.0f, 0.0f, 1.0f);
    glm::vec3 gTapeInnerPos = glm::vec3(-1.0f, 0.0f, 1.0f);
    glm::vec3 gTapeOuterPos = glm::vec3(-1.0f, 0.0f, 1.0f);


    // Cube and light color
    glm::vec3 gObjectColor(1.f, 0.2f, 0.0f);
    glm::vec3 gLightColor(0.0f, 1.0f, 0.0f);
    glm::vec3 gLight2Color(1.0f, 1.0f, 1.0f);
    glm::vec3 gLight3Color(1.0f, 1.0f, 1.0f);

    // Light position and scale
    glm::vec3 gLightPosition(1.5f, 3.0f, 5.0f);
    glm::vec3 gLightScale(0.3f);

    glm::vec3 gLight2Position(1.0f, 4.0f, 5.0f);
    glm::vec3 gLight2Scale(0.5f);

    glm::vec3 gLight3Position(1.0f, 1.2f, -2.0f);
    glm::vec3 gLight3Scale(0.3f);



    // Box Position and scale
    glm::vec3 gCubePosition(-1.0f, -0.1f, 0.0f);

    // Cylinder Position and scale
    glm::vec3 gCylinderPosition(2.5f, 0.0f, 0.05f);

    // Tape Inner Position and scale
    glm::vec3 gTapeInnerPosition(0.5f, 0.258f, 2.5f);

    // Tape Outer Position and scale
    glm::vec3 gTapeOuterPosition(0.5f, 0.258f, 2.5f);

    // Cylinder2 Position and scale
    glm::vec3 gCylinder2Position(2.5f, -0.135f, 0.05f);

    // Sphere Position and scale
    glm::vec3 gSpherePosition(2.5f, 0.2f, 0.05f);

    // Candle Base Position and scale
    glm::vec3 gCandlePosition(1.0f, 0.0f, -2.0f);

    // Candle Sphere Position and scale 
    glm::vec3 gCandCylPosition(1.0f, 0.5f, -2.0f);

    // Wick Position and scale
    glm::vec3 gCube2Position(1.0f, 0.8f, -2.0f);

    // Lamp animation
    bool gIsLampOrbiting = true;

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UCreateMeshCube(GLMesh& mesh);
void UCreateMeshPlane(GLMesh& mesh);
void UCreateMeshLights(GLMesh& mesh);
void UCreateMeshLight2(GLMesh& mesh);
void UCreateMeshCylinder(GLMesh& mesh);
void UCreateMeshCylinder2(GLMesh& mesh);
void UCreateMeshTapeInner(GLMesh& mesh);
void UCreateMeshTapeOuter(GLMesh& mesh);
void UCreateMeshSphere(GLMesh& mesh);
void UCreateMeshCandBase(GLMesh& mesh);
void UCreateMeshCandCyl(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


// Cylinder setup
// create a cylinder with default params;
// radii=1, height=1, sectors=36, stacks=1, smooth=true
//Cylinder cylinder = (0.1f, 0.1f, 1.0f, 1.0f, 3.0f, 3.0f, true);
Cylinder cylinder(1.0f, 0.1f, 0.3f, 36, 8.0f, true);         // baseRadius, topRadius, height, sectors, stacks, smooth shading (default)

// Cylinder2
Cylinder cylinder2(1.1f, 1.1f, 0.1f, 36, 8.0f, true);

// Sphere setup
Sphere sphere(0.1f, 16, 24, false);

// Candle Cylinder
Cylinder candCylinder(0.4f, 0.6f, 1.0f, 36, 8.0f, true);

// Tape Inner Cylinder
Cylinder tapeInner(0.8f, 0.8f, 0.901f, 36, 8.0f, true);

// Tape Outer Cylinder
Cylinder tapeOuter(0.9f, 0.9f, 0.9f, 36, 8.0f, true);




/* Plane and other objects Shader Source Code*/
const GLchar* lightingVertexShader = GLSL(440,
    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Plane and other objects Fragment Shader Source Code*/
const GLchar* lightingFragmentShader = GLSL(440,
    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor;

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 fillLightColor;
uniform vec3 fillLightPos;
uniform vec3 keyLightColor;
uniform vec3 keyLightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform sampler2D uTextureB;
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    // Texture holds the color to be used for all three components
    //vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
    vec3 textureColor = texture(uTexture, vertexTextureCoordinate).xyz;


    //Calculate Ambient lighting*/
    float ambientStrength = 0.1f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * fillLightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(fillLightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * fillLightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector

    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * fillLightColor;




    // Calculate Ambient lighting for key lamp
    float keyAmbientStrength = 0.4f;
    vec3 keyAmbient = keyAmbientStrength * keyLightColor;

    // Calculate Diffuse lighting for key lamp
    vec3 keyLightDirection = normalize(keyLightPos - vertexFragmentPos); // Calculate distance between key light source and fragments
    float keyImpact = max(dot(norm, keyLightDirection), 0.0);
    vec3 keyDiffuse = keyImpact * keyLightColor;

    // Calculate Specular lighting for key lamp
    float keySpecularIntensity = 1.5f; // Set specular light strength
    float keyHighlightSize = 32.0f; // Set specular highlight size
    vec3 keyReflectDir = reflect(-keyLightDirection, norm); // Calculate reflection vector
    //Calculate specular component
    float keySpecularComponent = pow(max(dot(viewDir, keyReflectDir), 0.0), keyHighlightSize);
    vec3 keySpecular = keySpecularIntensity * keySpecularComponent * keyLightColor;




    // Combine results
    vec3 fillResult = (ambient + diffuse + specular);
    vec3 keyResult = (keyAmbient + keyDiffuse + keySpecular);
    vec3 lightingResult = fillResult + keyResult;

    // Calculate phong result
    //vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;
    vec3 phong = (lightingResult)*textureColor;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Cylinder Fragment Shader Source Code*/
const GLchar* lighting2FragmentShader = GLSL(440,
    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor;

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 fillLightColor;
uniform vec3 fillLightPos;
uniform vec3 keyLightColor;
uniform vec3 keyLightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform sampler2D uTextureB;
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    // Texture holds the color to be used for all three components
    //vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
    vec3 textureColor = texture(uTexture, vertexTextureCoordinate).xyz;
    vec3 textureColorB = texture(uTextureB, vertexTextureCoordinate).xyz;


    //Calculate Ambient lighting*/
    float ambientStrength = 1.0f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * fillLightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(fillLightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * fillLightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.1f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector

    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * fillLightColor;




    // Calculate Ambient lighting for key lamp
    float keyAmbientStrength = 1.0f;
    vec3 keyAmbient = keyAmbientStrength * keyLightColor;

    // Calculate Diffuse lighting for key lamp
    vec3 keyLightDirection = normalize(keyLightPos - vertexFragmentPos); // Calculate distance between key light source and fragments
    float keyImpact = max(dot(norm, keyLightDirection), 0.0);
    vec3 keyDiffuse = keyImpact * keyLightColor;

    // Calculate Specular lighting for key lamp
    float keySpecularIntensity = 0.8f; // Set specular light strength
    float keyHighlightSize = 32.0f; // Set specular highlight size
    vec3 keyReflectDir = reflect(-keyLightDirection, norm); // Calculate reflection vector
    //Calculate specular component
    float keySpecularComponent = pow(max(dot(viewDir, keyReflectDir), 0.0), keyHighlightSize);
    vec3 keySpecular = keySpecularIntensity * keySpecularComponent * keyLightColor;




    // Combine results
    vec3 fillResult = (ambient + diffuse + specular);
    vec3 keyResult = (keyAmbient + keyDiffuse + keySpecular);
    vec3 lightingResult = fillResult + keyResult;

    // Calculate phong result
    //vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;
    vec3 phong = (lightingResult)*textureColor * textureColor2;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);


/* Light Cube Shader Source Code*/
const GLchar* lightCubeVertexShader = GLSL(440,
    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

            //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Light Cube Fragment Shader Source Code*/
const GLchar* lightCubeFragmentShader = GLSL(440,
    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);


// Key callback function to toggle ortho mode on key press
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS)
        ortho = !ortho;
}

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the mesh
    UCreateMeshPlane(gMeshPlane); // Calls the function to create the Vertex Buffer Object

    // Create the mesh
    UCreateMeshCube(gMeshCube); // Calls the function to create the Vertex Buffer Object

    // Create the mesh
    UCreateMeshCylinder(gMeshCylinder); // Calls the function to create the Vertex Buffer Object

    // Create the mesh
    UCreateMeshCylinder2(gMeshCylinder2); // Calls the function to create the Vertex Buffer Object

    // Create the mesh
    UCreateMeshSphere(gMeshSphere); // Calls function

    // Create the mesh
    UCreateMeshCandBase(gMeshCandBase); // Calls function

    // Create the mesh
    UCreateMeshCandCyl(gMeshCandCyl); // Calls function

    // Create the mesh
    UCreateMeshTapeInner(gMeshTapeInner); // Calls function

    // Create the mesh
    UCreateMeshTapeOuter(gMeshTapeOut); // Calls function

    // Create the mesh
    UCreateMeshLights(gMeshLights); // Calls the function to create the Vertex Buffer Object

    // Create the mesh
    UCreateMeshLight2(gMeshLight2); // Calls the function to create the Vertex Buffer Object


    // Create the shader program
    if (!UCreateShaderProgram(lightingVertexShader, lightingFragmentShader, gProgramId))
        return EXIT_FAILURE;


    // Create the light cube shader program
    if (!UCreateShaderProgram(lightCubeVertexShader, lightCubeFragmentShader, gLampProgramId))
        return EXIT_FAILURE;

    // Create the light cube shader program
    if (!UCreateShaderProgram(lightCubeVertexShader, lightCubeFragmentShader, gLamp2ProgramId))
        return EXIT_FAILURE;

    // Create the light cube shader program
    if (!UCreateShaderProgram(lightCubeVertexShader, lightCubeFragmentShader, gLamp3ProgramId))
        return EXIT_FAILURE;



    // Load texture 1
    const char* texFilename = "resources/textures/metal1.jpg";
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // Load texture 2
    const char* texFilename2 = "resources/textures/red.jpg";
    if (!UCreateTexture(texFilename2, gTextureId2))
    {
        cout << "Failed to load texture " << texFilename2 << endl;
        return EXIT_FAILURE;
    }

    // Load texture 3
    const char* texFilename3 = "resources/textures/Sugar Mug.jpg";
    if (!UCreateTexture(texFilename3, gTextureId3))
    {
        cout << "Failed to load texture " << texFilename3 << endl;
        return EXIT_FAILURE;
    }

    // Load texture 4
    const char* texFilename4 = "resources/textures/Plane.jpg";
    if (!UCreateTexture(texFilename4, gTextureId4))
    {
        cout << "Failed to load texture " << texFilename4 << endl;
        return EXIT_FAILURE;
    }

    // Load texture 5
    const char* texFilename5 = "resources/textures/brown.jpg";
    if (!UCreateTexture(texFilename5, gTextureId5))
    {
        cout << "Failed to load texture " << texFilename5 << endl;
        return EXIT_FAILURE;
    }

    // Load texture 6
    const char* texFilename6 = "resources/textures/darkBrown.jpg";
    if (!UCreateTexture(texFilename6, gTextureId6))
    {
        cout << "Failed to load texture " << texFilename6 << endl;
        return EXIT_FAILURE;
    }

    // Load texture 7
    const char* texFilename7 = "resources/textures/black.jpg";
    if (!UCreateTexture(texFilename7, gTextureId7))
    {
        cout << "Failed to load texture " << texFilename7 << endl;
        return EXIT_FAILURE;
    }

    // Load texture 8
    const char* texFilename8 = "resources/textures/redTape.jpg";
    if (!UCreateTexture(texFilename8, gTextureId8))
    {
        cout << "Failed to load texture " << texFilename8 << endl;
        return EXIT_FAILURE;
    }

    // Load texture 9
    const char* texFilename9 = "resources/textures/yellowTex.jpg";
    if (!UCreateTexture(texFilename9, gTextureId9))
    {
        cout << "Failed to load texture " << texFilename9 << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);

    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureB"), 1);


    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // Distance the camera travels is dictated by cameraSpeed, and time elapsed since the last frame
    // The time elapsed is computed within this render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        glfwSetKeyCallback(gWindow, key_callback);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    UDestroyMesh(gMeshCube);

    UDestroyMesh(gMeshPlane);

    UDestroyMesh(gMeshCylinder);

    UDestroyMesh(gMeshCylinder2);

    UDestroyMesh(gMeshSphere);

    UDestroyMesh(gMeshCandBase);

    UDestroyMesh(gMeshCandCyl);

    UDestroyMesh(gMeshTapeInner);

    UDestroyMesh(gMeshTapeOut);

    // Release shader program and light cube shader
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLampProgramId);
    UDestroyShaderProgram(gLamp2ProgramId);
    UDestroyShaderProgram(gLamp3ProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}

// Function called to render a frame using an orthographic matrix calculation
// Use GLM's lookAt to create a view matrix, requiring camera's position, the target, and the up vector of the camera.
void URender()
{

    // Lamp orbits around the origin
    const float angularVelocity = glm::radians(45.0f);
    if (gIsLampOrbiting)
    {
        glm::vec4 newPosition = glm::rotate(angularVelocity * gDeltaTime, glm::vec3(0.0f, 1.0f, 0.0f)) * glm::vec4(gLightPosition, 1.0f);
        gLightPosition.x = newPosition.x;
        gLightPosition.y = newPosition.y;
        gLightPosition.z = newPosition.z;
    }

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    //////// TRANSFORMATIONS

    // 1. Scales the object by 2
    glm::mat4 scale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    // 1. Scales the object by 2
    glm::mat4 candleBaseScale = glm::scale(glm::vec3(2.0f, 1.3f, 2.0f));
    // 1. Scales the object by 2
    glm::mat4 candleWickScale = glm::scale(glm::vec3(0.2f, 0.8f, 0.2f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 2.5. Rotates cylinder by 15 degrees in the x axis
    glm::mat4 cylinderRotation = glm::rotate(29.86f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 2.5. Rotates cylinder2 by 15 degrees in the x axis
    glm::mat4 cylinder2Rotation = glm::rotate(29.86f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 2.5. Rotates Cube2 by 15 degrees in the x axis
    glm::mat4 cube2Rotation = glm::rotate(29.86f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 2.5. Rotates CandleBase by 15 degrees in the x axis
    glm::mat4 candleBaseRotation = glm::rotate(31.5f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 2.5. Rotates CandleCyl by 15 degrees in the x axis
    glm::mat4 candleCylRotation = glm::rotate(29.86f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 2.5. Rotates cylinder2 by 15 degrees in the x axis
    glm::mat4 tapeInnerRotation = glm::rotate(29.86f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 2.5. Rotates cylinder2 by 15 degrees in the x axis
    glm::mat4 tapeOutRotation = glm::rotate(29.86f, glm::vec3(1.0f, 0.0f, 0.0f));

    // 3. Place plane at the origin
    glm::mat4 planeTranslation = glm::translate(gPlanePos);
    // 4. Place cube off center
    glm::mat4 cubeTranslation = glm::translate(gCubePos);
    // 4. Place cube2 off center
    glm::mat4 cube2Translation = glm::translate(gCube2Pos);
    // 5. Place cylinder off center
    glm::mat4 cylinderTranslation = glm::translate(gCylinderPos);
    // 6. Place cylinder2 off center
    glm::mat4 cylinder2Translation = glm::translate(gCylinder2Pos);
    // 6. Place Sphere off center
    glm::mat4 sphereTranslation = glm::translate(gSpherePos);
    // 6. Place CandleBase off center
    glm::mat4 candBaseTranslation = glm::translate(gCandBasePos);
    // 6. Place CandleCyl off center
    glm::mat4 candCylTranslation = glm::translate(gCandCylPos);
    // 6. Place CandleCyl off center
    glm::mat4 tapeInnerTranslation = glm::translate(gTapeInnerPos);
    // 6. Place CandleCyl off center
    glm::mat4 tapeOuterTranslation = glm::translate(gTapeOuterPos);



    /// MODEL VIEW PROJECTIONS
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 planeModel = planeTranslation * rotation * scale;
    glm::mat4 cubeModel = cubeTranslation * rotation * scale;
    glm::mat4 cube2Model = cube2Translation * cube2Rotation * candleWickScale;
    glm::mat4 cylinderModel = cylinderTranslation * cylinderRotation * scale;
    glm::mat4 cylinder2Model = cylinder2Translation * cylinder2Rotation * scale;
    glm::mat4 sphereModel = sphereTranslation * cylinderRotation * scale;
    glm::mat4 candBaseModel = candBaseTranslation * candleBaseRotation * candleBaseScale;
    glm::mat4 candCylModel = candCylTranslation * candleCylRotation * scale;
    glm::mat4 tapeInnerModel = tapeInnerTranslation * tapeInnerRotation * scale;
    glm::mat4 tapeOuterModel = tapeOuterTranslation * tapeOutRotation * scale;

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    // Creates a perspective projection
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Creates a perspective projection
    // set ortho flag to true when P is pressed
    if (ortho == true) {
        projection = glm::ortho(-((GLfloat)WINDOW_WIDTH / 100.0f), (GLfloat)WINDOW_WIDTH / 100.0f, (GLfloat)WINDOW_HEIGHT / 100.0f, -((GLfloat)WINDOW_HEIGHT / 100.0f), -1000.0f, 1000.0f);
    }
    else {
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }

    // Retrieves and passes Plane transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    GLint fillLightColorLoc = glGetUniformLocation(gProgramId, "fillLightColor");
    GLint fillLightPositionLoc = glGetUniformLocation(gProgramId, "fillLightPos");
    GLint keyLightColorLoc = glGetUniformLocation(gProgramId, "keyLightColor");
    GLint keyLightPositionLoc = glGetUniformLocation(gProgramId, "keyLightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");

    ///// PLANE MODEL
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshPlane.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(planeModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));


    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(fillLightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(fillLightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    glUniform3f(keyLightColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
    glUniform3f(keyLightPositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);


    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));


    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId4);

    // Draws the triangles
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMeshPlane.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    //////////////// LAMP

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshLights.vao);
    glUseProgram(gLampProgramId);

    //Transform the smaller cube used as a visual que for the light source
    cubeModel = glm::translate(gLightPosition) * glm::scale(gLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cubeModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gMeshLights.nIndices);

    ///// DRAW THE LAMP SECOND
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshLights.vao);
    glUseProgram(gLamp2ProgramId);

    //Transform the smaller cube used as a visual que for the light source
    cubeModel = glm::translate(gLight2Position) * glm::scale(gLight2Scale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLamp2ProgramId, "model");
    viewLoc = glGetUniformLocation(gLamp2ProgramId, "view");
    projLoc = glGetUniformLocation(gLamp2ProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cubeModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gMeshLights.nIndices);

    ///// DRAW THE LAMP THIRD
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshLight2.vao);
    glUseProgram(gLamp3ProgramId);

    //Transform the smaller cube used as a visual que for the light source
    cubeModel = glm::translate(gLight3Position) * glm::scale(gLight3Scale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLamp2ProgramId, "model");
    viewLoc = glGetUniformLocation(gLamp2ProgramId, "view");
    projLoc = glGetUniformLocation(gLamp2ProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cubeModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gMeshLights.nIndices);

    //////////////////// SugarLid
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    cubeModel = glm::translate(gCubePosition) * rotation;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cubeModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    //////////////////// CandleWick
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshCube.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    cubeModel = glm::translate(gCube2Position) * rotation * candleWickScale;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cubeModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId6);

    //// Draws the triangles
    glDrawElements(GL_TRIANGLES, gMeshCube.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle


    /////////////// CYLINDER
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshCylinder.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    cylinderModel = glm::translate(gCylinderPosition) * cylinderRotation;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cylinderModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    // Draws the triangles
// draw a cylinder with VBO
    
    glDrawElements(GL_TRIANGLES,         // primitive type
        cylinder.getIndexCount(),        // # of indices
        GL_UNSIGNED_INT,                 // data type
        (void*)0);                       // offset to indices

    /////////////// CYLINDER2
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshCylinder2.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    cylinder2Model = glm::translate(gCylinder2Position) * cylinder2Rotation;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(cylinder2Model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    // Draws the triangles
    // draw a cylinder2 with VBO
    glDrawElements(GL_TRIANGLES,         // primitive type
        cylinder2.getIndexCount(),        // # of indices
        GL_UNSIGNED_INT,                 // data type
        (void*)0);                       // offset to indices

    /////////////// Tape Inner Cylinder
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshTapeInner.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    tapeInnerModel = glm::translate(gTapeInnerPosition) * tapeInnerRotation;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(tapeInnerModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId7);

    // Draws the triangles
// draw a cylinder with VBO

    glDrawElements(GL_TRIANGLES,         // primitive type
        tapeInner.getIndexCount(),        // # of indices
        GL_UNSIGNED_INT,                 // data type
        (void*)0);                       // offset to indices

    /////////////// Tape Outer Cylinder
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshTapeOut.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    tapeOuterModel = glm::translate(gTapeOuterPosition) * tapeOutRotation;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(tapeOuterModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId2);

    // Draws the triangles
// draw a cylinder with VBO

    glDrawElements(GL_TRIANGLES,         // primitive type
        tapeOuter.getIndexCount(),        // # of indices
        GL_UNSIGNED_INT,                 // data type
        (void*)0);                       // offset to indices

     /////////////// SPHERE
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshSphere.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    sphereModel = glm::translate(gSpherePosition) * cylinderRotation;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(sphereModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId5);

    // Draws the triangles
    // draw a Sphere with VBO
    glDrawElements(GL_TRIANGLES,         // primitive type
        sphere.getIndexCount(),        // # of indices
        GL_UNSIGNED_INT,                 // data type
        (void*)0);                       // offset to indices


        //////////////////// Candle Base
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshCandBase.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    candBaseModel = glm::translate(gCandlePosition) * candleBaseRotation * candleBaseScale;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(candBaseModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMeshCandBase.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        /////////////// Candle Cylinder
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMeshCandCyl.vao);

    // Set the shader to be used
    glUseProgram(gProgramId);

    //Transform the smaller cube used as a visual que for the light source
    candCylModel = glm::translate(gCandCylPosition) * candleCylRotation;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(candCylModel));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId9);

    // Draws the triangles
    // draw a cylinder2 with VBO
    glDrawElements(GL_TRIANGLES,         // primitive type
        candCylinder.getIndexCount(),        // # of indices
        GL_UNSIGNED_INT,                 // data type
        (void*)0);                       // offset to indices

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
    glUseProgram(0);


    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// tie keystrokes to the actions of moving the camera, keeping gCameraPos up to date
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS && gTexWrapMode != GL_REPEAT)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_REPEAT;

        cout << "Current Texture Wrapping Mode: REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS && gTexWrapMode != GL_MIRRORED_REPEAT)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_MIRRORED_REPEAT;

        cout << "Current Texture Wrapping Mode: MIRRORED REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_EDGE)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_EDGE;

        cout << "Current Texture Wrapping Mode: CLAMP TO EDGE" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_BORDER)
    {
        float color[] = { 1.0f, 0.0f, 1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color);

        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_BORDER;

        cout << "Current Texture Wrapping Mode: CLAMP TO BORDER" << endl;
    }

    if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
    {
        gUVScale += 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
    {
        gUVScale -= 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }

    // Pause and resume lamp orbiting
    static bool isLKeyDown = false;
    if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS && !gIsLampOrbiting)
        gIsLampOrbiting = true;
    else if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS && gIsLampOrbiting)
        gIsLampOrbiting = false;

}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Implements the UCreateMesh function
void UCreateMeshLights(GLMesh& mesh)
{
    // Vertex data for a Pyramid, with textures
    GLfloat verts[] =
    {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
        0.0f,  0.5f,  0.0f,     0.0f,  0.0f, -1.0f,    0.5f, 1.0f,
         0.5f, -0.5f, -0.5f,     0.0f,  0.0f, -1.0f,    0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,     0.0f,  0.0f, -1.0f,    1.0f, 0.0f,

        //Front Face            //Positive Z Normals
         0.0f,  0.5f,  0.0f,     0.0f,  0.0f,  1.0f,    0.5f, 1.0f,
        -0.5f, -0.5f,  0.5f,     0.0f,  0.0f,  1.0f,    0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,     0.0f,  0.0f,  1.0f,    1.0f, 0.0f,

         //Left Face            //Negative X Normals
           0.0f,  0.5f,  0.0f,    -1.0f,  0.0f,  0.0f,    0.5f, 1.0f,
           -0.5f, -0.5f, -0.5f,    -1.0f,  0.0f,  0.0f,    0.0f, 0.0f,
           -0.5f, -0.5f,  0.5f,    -1.0f,  0.0f,  0.0f,    1.0f, 0.0f,

           //Right Face           //Positive X Normals
             0.0f,  0.5f,  0.0f,     1.0f,  0.0f,  0.0f,    0.5f, 1.0f,
             0.5f, -0.5f,  0.5f,     1.0f,  0.0f,  0.0f,    0.0f, 0.0f,
             0.5f, -0.5f, -0.5f,     1.0f,  0.0f,  0.0f,    1.0f, 0.0f,

             //Bottom Face          //Negative Y Normals
              -0.5f, -0.5f, -0.5f,     0.0f, -1.0f,  0.0f,    0.0f, 1.0f,
              0.5f, -0.5f, -0.5f,     0.0f, -1.0f,  0.0f,    0.0f, 0.0f,
              -0.5f, -0.5f,  0.5f,     0.0f, -1.0f,  0.0f,    1.0f, 1.0f,
              -0.5f, -0.5f,  0.5f,     0.0f, -1.0f,  0.0f,    1.0f, 1.0f,
               0.5f, -0.5f, -0.5f,     0.0f, -1.0f,  0.0f,    0.0f, 0.0f,
               0.5f, -0.5f,  0.5f,     0.0f, -1.0f,  0.0f,    1.0f, 0.0f,
    };

    // Indices for a pyramid
    GLushort indices[] =
    {
        0, 1, 2,
        0, 2, 3,
        0, 1, 4,
        1, 2, 4,
        2, 3, 4,
        3, 0, 4
    };

    // These values help calculate the stride
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    // hold the number of indices
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshLight2(GLMesh& mesh)
{
    // Vertex data for a Pyramid, with textures
    GLfloat verts[] =
    {
        // Vertex Positions       // Normal Coords         // Texture

       // BACK
       -0.1f, -0.1f, -0.1f,       0.0f, 0.0f, -1.0f,      1.0f,  0.0f,    // Vertex 0
        0.1f, -0.1f, -0.1f,       0.0f, 0.0f, -1.0f,     -1.0f, 0.0f,    // Vertex 1
        0.1f,  0.5f, -0.1f,       0.0f, 0.0f, -1.0f,      1.0f,  1.0f,    // Vertex 2
       -0.1f,  0.5f, -0.1f,       0.0f, 0.0f, -1.0f,      0.0f,  1.0f,    // Vertex 3

       // FRONT
       -0.1f, -0.1f,  0.1f,       0.0f, 0.0f, 1.0f,       1.0f,  0.0f,     // Vertex 4
        0.1f, -0.1f,  0.1f,       0.0f, 0.0f, 1.0f,      -1.0f, 0.0f,     // Vertex 5
        0.1f,  0.5f,  0.1f,       0.0f, 0.0f, 1.0f,       1.0f,  1.0f,     // Vertex 6
       -0.1f,  0.5f,  0.1f,       0.0f, 0.0f, 1.0f,       0.0f,  1.0f,     // Vertex 7

       // LEFT
       -0.1f,  0.5f,  0.1f,      -1.0f, 0.0f, 0.0f,       1.0f,  0.0f,     // Vertex 8
       -0.1f,  0.5f, -0.1f,      -1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 9
       -0.1f, -0.1f, -0.1f,      -1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 10
       -0.1f, -0.1f,  0.1f,      -1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 11

       // RIGHT
        0.1f,  0.5f,  0.1f,       1.0f, 0.0f, 0.0f,       1.0f, 0.0f,     // Vertex 12
        0.1f,  0.5f, -0.1f,       1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 13
        0.1f, -0.1f, -0.1f,       1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 14
        0.1f, -0.1f,  0.1f,       1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 15

        // TOP
        -0.1f,  0.5f, -0.1f,      0.0f, 1.0f, 0.0f,       1.0f, 0.0f,     // Vertex 16
         0.1f,  0.5f, -0.1f,      0.0f, 1.0f, 0.0f,      -1.0f, 0.0f,    // Vertex 17
         0.1f,  0.5f,  0.1f,      0.0f, 1.0f, 0.0f,       1.0f,  1.0f,    // Vertex 18
        -0.1f,  0.5f,  0.1f,      0.0f, 1.0f, 0.0f,       0.0f,  1.0f,    // Vertex 19

         // BOTTOM
        -0.1f,  -0.1f, -0.1f,      0.0f, -1.0f, 0.0f,       1.0f, 0.0f,     // Vertex 20
         0.1f,  -0.1f, -0.1f,      0.0f, -1.0f, 0.0f,      -1.0f, 0.0f,    // Vertex 21
         0.1f,  -0.1f,  0.1f,      0.0f, -1.0f, 0.0f,       1.0f,  1.0f,    // Vertex 22
        -0.1f,  -0.1f,  0.1f,      0.0f, -1.0f, 0.0f,       0.0f,  1.0f    // Vertex 23
    };

    // Indices for a pyramid
    GLushort indices[] =
    {
    0, 1, 2,
    2, 3, 0,
    4, 5, 6,
    6, 7, 4,
    8, 9, 10,
    10, 11, 8,
    12, 13, 14,
    14, 15, 12,
    16, 17, 18,
    18, 19, 16,
    20, 21, 22,
    22, 23, 20
    };

    // These values help calculate the stride
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    // hold the number of indices
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    // Vertex data for a sugar lid
    GLfloat verts[] =
    { 
     // Sugar Lid 
     // BottomBox
        // Vertex Positions       // Normal Coords         // Texture

       // BACK
       -0.7f, -0.1f, -0.7f,       0.0f, 0.0f, -1.0f,      1.0f,  0.0f,    // Vertex 0
        0.7f, -0.1f, -0.7f,       0.0f, 0.0f, -1.0f,     -1.0f, 0.0f,    // Vertex 1
        0.7f,  0.2f, -0.7f,       0.0f, 0.0f, -1.0f,      1.0f,  1.0f,    // Vertex 2
       -0.7f,  0.2f, -0.7f,       0.0f, 0.0f, -1.0f,      0.0f,  1.0f,    // Vertex 3

       // FRONT
       -0.7f, -0.1f,  0.7f,       0.0f, 0.0f, 1.0f,       1.0f,  0.0f,     // Vertex 4
        0.7f, -0.1f,  0.7f,       0.0f, 0.0f, 1.0f,      -1.0f, 0.0f,     // Vertex 5
        0.7f,  0.2f,  0.7f,       0.0f, 0.0f, 1.0f,       1.0f,  1.0f,     // Vertex 6
       -0.7f,  0.2f,  0.7f,       0.0f, 0.0f, 1.0f,       0.0f,  1.0f,     // Vertex 7

       // LEFT
       -0.7f,  0.2f,  0.7f,      -1.0f, 0.0f, 0.0f,       1.0f,  0.0f,     // Vertex 8
       -0.7f,  0.2f, -0.7f,      -1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 9
       -0.7f, -0.1f, -0.7f,      -1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 10
       -0.7f, -0.1f,  0.7f,      -1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 11

       // RIGHT
        0.7f,  0.2f,  0.7f,       1.0f, 0.0f, 0.0f,       1.0f, 0.0f,     // Vertex 12
        0.7f,  0.2f, -0.7f,       1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 13
        0.7f, -0.1f, -0.7f,       1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 14
        0.7f, -0.1f,  0.7f,       1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 15

        // TOP
        -0.7f,  0.2f, -0.7f,      0.0f, 1.0f, 0.0f,       1.0f, 0.0f,     // Vertex 16
         0.7f,  0.2f, -0.7f,      0.0f, 1.0f, 0.0f,      -1.0f, 0.0f,    // Vertex 17
         0.7f,  0.2f,  0.7f,      0.0f, 1.0f, 0.0f,       1.0f,  1.0f,    // Vertex 18
        -0.7f,  0.2f,  0.7f,      0.0f, 1.0f, 0.0f,       0.0f,  1.0f,    // Vertex 19

        // Top Box
                // BACK
       -0.6f,  0.2f, -0.6f,      0.0f, 0.0f, -1.0f,       1.0f, 0.0f,     // Vertex 20
        0.6f,  0.2f, -0.6f,      0.0f, 0.0f, -1.0f,      -1.0f, 0.0f,    // Vertex 21
        0.6f,  0.4f, -0.6f,      0.0f, 0.0f, -1.0f,       1.0f,  1.0f,    // Vertex 22
       -0.6f,  0.4f, -0.6f,      0.0f, 0.0f, -1.0f,       0.0f,  1.0f,     // Vertex 23

       // FRONT
       -0.6f,  0.2f,  0.6f,      0.0f, 0.0f, 1.0f,        1.0f, 0.0f,     // Vertex 24
        0.6f,  0.2f,  0.6f,      0.0f, 0.0f, 1.0f,       -1.0f, 0.0f,    // Vertex 25
        0.6f,  0.4f,  0.6f,      0.0f, 0.0f, 1.0f,        1.0f,  1.0f,    // Vertex 26
       -0.6f,  0.4f,  0.6f,      0.0f, 0.0f, 1.0f,        0.0f,  1.0f,    // Vertex 27

       // LEFT
       -0.6f,  0.4f,  0.6f,     -1.0f, 0.0f, 0.0f,        1.0f, 0.0f,     // Vertex 28
       -0.6f,  0.4f, -0.6f,     -1.0f, 0.0f, 0.0f,       -1.0f, 0.0f,    // Vertex 29
       -0.6f,  0.2f, -0.6f,     -1.0f, 0.0f, 0.0f,        1.0f,  1.0f,    // Vertex 30
       -0.6f,  0.2f,  0.6f,     -1.0f, 0.0f, 0.0f,        0.0f,  1.0f,    // Vertex 31

       // RIGHT
        0.6f,  0.4f,  0.6f,      1.0f, 0.0f, 0.0f,        1.0f, 0.0f,     // Vertex 32
        0.6f,  0.4f, -0.6f,      1.0f, 0.0f, 0.0f,       -1.0f, 0.0f,     // Vertex 33
        0.6f,  0.2f, -0.6f,      1.0f, 0.0f, 0.0f,        1.0f, 1.0f,     // Vertex 34
        0.6f,  0.2f,  0.6f,      1.0f, 0.0f, 0.0f,        0.0f,  1.0f,    // Vertex 35


        // TOP
        -0.6f,  0.4f, -0.6f,    0.0f, 1.0f, 0.0f,         1.0f, 0.0f,     // Vertex 36
         0.6f,  0.4f, -0.6f,    0.0f, 1.0f, 0.0f,        -1.0f, 0.0f,     // Vertex 37
         0.6f,  0.4f,  0.6f,    0.0f, 1.0f, 0.0f,         1.0f, 1.0f,     // Vertex 38
        -0.6f,  0.4f,  0.6f,    0.0f, 1.0f, 0.0f,         0.0f,  1.0f    // Vertex 39
    };

    // Indices for a pyramid
    GLushort indices[] =
    {
    0, 1, 2,
    2, 3, 0,
    4, 5, 6,
    6, 7, 4,
    8, 9, 10,
    10, 11, 8,
    12, 13, 14,
    14, 15, 12,
    16, 17, 18,
    18, 19, 16,
    20, 21, 22,
    22, 23, 20,
    24, 25, 26,
    26, 27, 24,
    28, 29, 30,
    30, 31, 28,
    32, 33, 34,
    34, 35, 32,
    36, 37, 38,
    38, 39, 36
    };

    // These values help calculate the stride
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // hold the number of indices
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshCube(GLMesh& mesh)
{
    // Vertex data for a sugar lid
    GLfloat cubeVerts[] =
    {
        // Container Top 
           // Vertex Positions       // Normal Coords         // Texture

          // BACK
          -0.1f, -0.1f, -0.1f,       0.0f, 0.0f, -1.0f,      1.0f,  0.0f,    // Vertex 0
           0.1f, -0.1f, -0.1f,       0.0f, 0.0f, -1.0f,     -1.0f, 0.0f,    // Vertex 1
           0.1f,  0.5f, -0.1f,       0.0f, 0.0f, -1.0f,      1.0f,  1.0f,    // Vertex 2
          -0.1f,  0.5f, -0.1f,       0.0f, 0.0f, -1.0f,      0.0f,  1.0f,    // Vertex 3

          // FRONT
          -0.1f, -0.1f,  0.1f,       0.0f, 0.0f, 1.0f,       1.0f,  0.0f,     // Vertex 4
           0.1f, -0.1f,  0.1f,       0.0f, 0.0f, 1.0f,      -1.0f, 0.0f,     // Vertex 5
           0.1f,  0.5f,  0.1f,       0.0f, 0.0f, 1.0f,       1.0f,  1.0f,     // Vertex 6
          -0.1f,  0.5f,  0.1f,       0.0f, 0.0f, 1.0f,       0.0f,  1.0f,     // Vertex 7

          // LEFT
          -0.1f,  0.5f,  0.1f,      -1.0f, 0.0f, 0.0f,       1.0f,  0.0f,     // Vertex 8
          -0.1f,  0.5f, -0.1f,      -1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 9
          -0.1f, -0.1f, -0.1f,      -1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 10
          -0.1f, -0.1f,  0.1f,      -1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 11

          // RIGHT
           0.1f,  0.5f,  0.1f,       1.0f, 0.0f, 0.0f,       1.0f, 0.0f,     // Vertex 12
           0.1f,  0.5f, -0.1f,       1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 13
           0.1f, -0.1f, -0.1f,       1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 14
           0.1f, -0.1f,  0.1f,       1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 15

           // TOP
           -0.1f,  0.5f, -0.1f,      0.0f, 1.0f, 0.0f,       1.0f, 0.0f,     // Vertex 16
            0.1f,  0.5f, -0.1f,      0.0f, 1.0f, 0.0f,      -1.0f, 0.0f,    // Vertex 17
            0.1f,  0.5f,  0.1f,      0.0f, 1.0f, 0.0f,       1.0f,  1.0f,    // Vertex 18
           -0.1f,  0.5f,  0.1f,      0.0f, 1.0f, 0.0f,       0.0f,  1.0f,    // Vertex 19
           
            // BOTTOM
           -0.1f,  -0.1f, -0.1f,      0.0f, -1.0f, 0.0f,       1.0f, 0.0f,     // Vertex 20
            0.1f,  -0.1f, -0.1f,      0.0f, -1.0f, 0.0f,      -1.0f, 0.0f,    // Vertex 21
            0.1f,  -0.1f,  0.1f,      0.0f, -1.0f, 0.0f,       1.0f,  1.0f,    // Vertex 22
           -0.1f,  -0.1f,  0.1f,      0.0f, -1.0f, 0.0f,       0.0f,  1.0f    // Vertex 23
    };

    // Indices for a pyramid
    GLushort indices[] =
    {
    0, 1, 2,
    2, 3, 0,
    4, 5, 6,
    6, 7, 4,
    8, 9, 10,
    10, 11, 8,
    12, 13, 14,
    14, 15, 12,
    16, 17, 18,
    18, 19, 16,
    20, 21, 22,
    22, 23, 20
    };

    // These values help calculate the stride
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVerts), cubeVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // hold the number of indices
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshPlane(GLMesh& mesh)
{
    // Vertex data for a Plane, with Texture
    GLfloat verts[] =
    { //     COORDINATES      Norm Coords       Textures
    -5.0f, -0.1f,  5.0f,	 0.0f,  1.0f,      0.0f, 1.0f, 1.0f,
    -5.0f, -0.1f, -5.0f,	 0.0f,  1.0f,      0.0f, 1.0f, 0.0f,
     5.0f, -0.1f, -5.0f,	 0.0f,  1.0f,      0.0f, 0.0f, 0.0f,
     5.0f, -0.1f,  5.0f,	 0.0f,  1.0f,      0.0f, 0.0f, 1.0f
    };

    // Indices for a plane
    GLushort indices[] =
    {
        0, 1, 2,
        0, 2, 3
    };

    // These values help calculate the stride
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // hold the number of indices
    // hold the number of indices
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


// Implements the UCreateMesh function
void UCreateMeshCylinder(GLMesh& mesh)
{
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);             // for vertex data
    glBufferData(GL_ARRAY_BUFFER,                     // target
        cylinder.getInterleavedVertexSize(), // data size, # of bytes
        cylinder.getInterleavedVertices(),   // ptr to vertex data
        GL_STATIC_DRAW);                     // usage

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);     // for index data
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,             // target
        cylinder.getIndexSize(),             // data size, # of bytes
        cylinder.getIndices(),               // ptr to index data
        GL_STATIC_DRAW);                     // usage

    // bind VBOs
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);

    // set attrib arrays with stride and offset
    int stride = cylinder.getInterleavedStride();   // should be 32 bytes
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(2, 2, GL_FLOAT, false, stride, (void*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshCylinder2(GLMesh& mesh)
{
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);             // for vertex data
    glBufferData(GL_ARRAY_BUFFER,                     // target
        cylinder2.getInterleavedVertexSize(), // data size, # of bytes
        cylinder2.getInterleavedVertices(),   // ptr to vertex data
        GL_STATIC_DRAW);                     // usage

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);     // for index data
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,             // target
        cylinder2.getIndexSize(),             // data size, # of bytes
        cylinder2.getIndices(),               // ptr to index data
        GL_STATIC_DRAW);                     // usage

    // bind VBOs
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);

    // set attrib arrays with stride and offset
    int stride = cylinder2.getInterleavedStride();   // should be 32 bytes
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(2, 2, GL_FLOAT, false, stride, (void*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshSphere(GLMesh& mesh)
{
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);             // for vertex data
    glBufferData(GL_ARRAY_BUFFER,                     // target
        sphere.getInterleavedVertexSize(), // data size, # of bytes
        sphere.getInterleavedVertices(),   // ptr to vertex data
        GL_STATIC_DRAW);                     // usage

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);     // for index data
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,             // target
        sphere.getIndexSize(),             // data size, # of bytes
        sphere.getIndices(),               // ptr to index data
        GL_STATIC_DRAW);                     // usage

    // bind VBOs
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);

    // set attrib arrays with stride and offset
    int stride = sphere.getInterleavedStride();   // should be 32 bytes
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(2, 2, GL_FLOAT, false, stride, (void*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshTapeInner(GLMesh& mesh)
{
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);             // for vertex data
    glBufferData(GL_ARRAY_BUFFER,                     // target
        tapeInner.getInterleavedVertexSize(), // data size, # of bytes
        tapeInner.getInterleavedVertices(),   // ptr to vertex data
        GL_STATIC_DRAW);                     // usage

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);     // for index data
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,             // target
        tapeInner.getIndexSize(),             // data size, # of bytes
        tapeInner.getIndices(),               // ptr to index data
        GL_STATIC_DRAW);                     // usage

    // bind VBOs
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);

    // set attrib arrays with stride and offset
    int stride = tapeInner.getInterleavedStride();   // should be 32 bytes
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(2, 2, GL_FLOAT, false, stride, (void*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshTapeOuter(GLMesh& mesh)
{
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);             // for vertex data
    glBufferData(GL_ARRAY_BUFFER,                     // target
        tapeOuter.getInterleavedVertexSize(), // data size, # of bytes
        tapeOuter.getInterleavedVertices(),   // ptr to vertex data
        GL_STATIC_DRAW);                     // usage

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);     // for index data
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,             // target
        tapeOuter.getIndexSize(),             // data size, # of bytes
        tapeOuter.getIndices(),               // ptr to index data
        GL_STATIC_DRAW);                     // usage

    // bind VBOs
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);

    // set attrib arrays with stride and offset
    int stride = tapeOuter.getInterleavedStride();   // should be 32 bytes
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(2, 2, GL_FLOAT, false, stride, (void*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}



// Implements the UCreateMesh function
void UCreateMeshCandBase(GLMesh& mesh)
{
    // Vertex data for a sugar lid
    GLfloat candBaseVerts[] =
    {
        // Container Top 
           // Vertex Positions       // Normal Coords         // Texture

          // BACK
          -0.3f, -0.1f, -0.3f,       0.0f, 0.0f, -1.0f,      1.0f,  0.0f,    // Vertex 0
           0.3f, -0.1f, -0.3f,       0.0f, 0.0f, -1.0f,     -1.0f, 0.0f,    // Vertex 1
           0.3f,  0.8f, -0.3f,       0.0f, 0.0f, -1.0f,      1.0f,  1.0f,    // Vertex 2
          -0.3f,  0.8f, -0.3f,       0.0f, 0.0f, -1.0f,      0.0f,  1.0f,    // Vertex 3

          // FRONT
          -0.3f, -0.1f,  0.3f,       0.0f, 0.0f, 1.0f,       1.0f,  0.0f,     // Vertex 4
           0.3f, -0.1f,  0.3f,       0.0f, 0.0f, 1.0f,      -1.0f, 0.0f,     // Vertex 5
           0.3f,  0.8f,  0.3f,       0.0f, 0.0f, 1.0f,       1.0f,  1.0f,     // Vertex 6
          -0.3f,  0.8f,  0.3f,       0.0f, 0.0f, 1.0f,       0.0f,  1.0f,     // Vertex 7

          // LEFT
          -0.3f,  0.8f,  0.3f,      -1.0f, 0.0f, 0.0f,       1.0f,  0.0f,     // Vertex 8
          -0.3f,  0.8f, -0.3f,      -1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 9
          -0.3f, -0.1f, -0.3f,      -1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 10
          -0.3f, -0.1f,  0.3f,      -1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 11

          // RIGHT
           0.3f,  0.8f,  0.3f,       1.0f, 0.0f, 0.0f,       1.0f, 0.0f,     // Vertex 12
           0.3f,  0.8f, -0.3f,       1.0f, 0.0f, 0.0f,      -1.0f, 0.0f,     // Vertex 13
           0.3f, -0.1f, -0.3f,       1.0f, 0.0f, 0.0f,       1.0f,  1.0f,     // Vertex 14
           0.3f, -0.1f,  0.3f,       1.0f, 0.0f, 0.0f,       0.0f,  1.0f,     // Vertex 15

            // BOTTOM
           -0.3f,  -0.1f, -0.3f,      0.0f, -1.0f, 0.0f,       1.0f, 0.0f,     // Vertex 16
            0.3f,  -0.1f, -0.3f,      0.0f, -1.0f, 0.0f,      -1.0f, 0.0f,    // Vertex 17
            0.3f,  -0.1f,  0.3f,      0.0f, -1.0f, 0.0f,       1.0f,  1.0f,    // Vertex 18
           -0.3f,  -0.1f,  0.3f,      0.0f, -1.0f, 0.0f,       0.0f,  1.0f    // Vertex 19
    };

    // Indices for a pyramid
    GLushort indices[] =
    {
    0, 1, 2,
    2, 3, 0,
    4, 5, 6,
    6, 7, 4,
    8, 9, 10,
    10, 11, 8,
    12, 13, 14,
    14, 15, 12,
    16, 17, 18,
    18, 19, 16
    };

    // These values help calculate the stride
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(candBaseVerts), candBaseVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // hold the number of indices
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateMeshCandCyl(GLMesh& mesh)
{
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);             // for vertex data
    glBufferData(GL_ARRAY_BUFFER,                     // target
        candCylinder.getInterleavedVertexSize(), // data size, # of bytes
        candCylinder.getInterleavedVertices(),   // ptr to vertex data
        GL_STATIC_DRAW);                     // usage

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);     // for index data
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,             // target
        candCylinder.getIndexSize(),             // data size, # of bytes
        candCylinder.getIndices(),               // ptr to index data
        GL_STATIC_DRAW);                     // usage

    // bind VBOs
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);

    // set attrib arrays with stride and offset
    int stride = candCylinder.getInterleavedStride();   // should be 32 bytes
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(2, 2, GL_FLOAT, false, stride, (void*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}

void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}